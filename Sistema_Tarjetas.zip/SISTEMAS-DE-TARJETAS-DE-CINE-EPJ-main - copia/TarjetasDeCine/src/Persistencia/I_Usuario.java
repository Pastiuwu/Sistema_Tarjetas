/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Persistencia;

import Entidades.Usuario;

/**
 *
 * @author Usuario
 */
public interface I_Usuario {
    
    boolean agregarUsuario(Usuario A);
    boolean eliminarUsuario(Usuario A);
}
